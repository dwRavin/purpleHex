package com.example.hp.purplehex;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Admin_Home extends Activity {
    private static long back_pressed;
    Button addprdt,adduser;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin__home);
        adduser = (Button) findViewById(R.id.add_user);
        adduser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(Admin_Home.this,SignUp.class);
                startActivity(intent1);
                Admin_Home.this.finish();
            }
        });
        addprdt=(Button)findViewById(R.id.addproduct);
        addprdt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent inte=new Intent(Admin_Home.this,ProductAdd.class);
                startActivity(inte);
                Admin_Home.this.finish();
            }
        });
    }
    @Override
    public void onBackPressed() {
        if (back_pressed + 2000 > System.currentTimeMillis()){
            startActivity(new Intent(Admin_Home.this,landing_page.class));
            Admin_Home.this.finish();
        }
        else{
            Toast.makeText(getBaseContext(), "Press once again to logout", Toast.LENGTH_SHORT).show();
            back_pressed = System.currentTimeMillis();
        }
    }

}
