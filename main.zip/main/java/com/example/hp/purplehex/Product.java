package com.example.hp.purplehex;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Product extends Activity {
    SQLiteDatabase pattustore;
    Button rm;
    int key;
    TextView t1,t2,t3;
    String name;
    Cursor c;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product);

            pattustore = openOrCreateDatabase("pattubookdb",0, null);
            t1=(TextView)findViewById(R.id.pid);
            t2=(TextView)findViewById(R.id.pname);
            t3=(TextView)findViewById(R.id.amt);
            rm=(Button)findViewById(R.id.remove);



            name= getIntent().getStringExtra("name");
            Log.d("test name",name);

        //pattustore.execSQL("CREATE TABLE IF NOT EXISTS  billing ( keyid integer primary key autoincrement,pid text not null,pname text not null,amount text,created_date date default CURRENT_DATE)");

            //pattustore.execSQL("CREATE TABLE IF NOT EXISTS  customer_table ( keyid integer primary key autoincrement,name varchar,phone varchar,amount varchar,created_date date default CURRENT_DATE)");
            // pattustore.execSQL("insert into customer_table values(NULL,'midhun','95262435353','500',datetime())");
            try {

                c = pattustore.rawQuery("select * from billing where pname ='" + name + "'", null);
                c.moveToFirst();
            }
            catch (java.lang.RuntimeException e){
                Log.d("error","qwdfsd ");
            }
            t1.setText(c.getString(1));
            t2.setText(c.getString(2));
            t3.setText(c.getString(3));


        key=c.getInt(0);
        //Toast.makeText(getBaseContext(),key,Toast.LENGTH_LONG).show();
          /*  rm.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    try {
                        pattustore.execSQL("delete from billing where keyid='"+key+"'");
                    }catch (java.lang.RuntimeException e){
                        Log.d("error","qwdfsd ");
                    }

                    Intent i =new Intent(getApplicationContext(),ProductList.class);
                    startActivity(i);
                    Product.this.finish();
                }
            });*/
     }
}
