package com.example.hp.purplehex;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;


public class MyAdapter extends CursorAdapter {


    public MyAdapter(Context context, Cursor c) {
        super(context, c);

    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {

        return LayoutInflater.from(context).inflate(R.layout.activity_my_adapter, parent, false);



    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        TextView customer=(TextView)view.findViewById(R.id.textView);
        TextView amount=(TextView)view.findViewById(R.id.textView2);

        String customer_text = cursor.getString(3);
        String amount_text = cursor.getString(4);

        customer.setText(customer_text);
        amount.setText(amount_text);


    }

}
