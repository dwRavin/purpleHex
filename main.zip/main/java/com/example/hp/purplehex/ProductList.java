package com.example.hp.purplehex;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

public class ProductList extends Activity {
    private static long back_pressed;
    ProductDataBaseAdapter productDataBaseAdapter;
    SQLiteDatabase pattustore;
    Button buymore,bill;
    String name,pname,pid,cost,uname;
    IntentIntegrator qrScan;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_list);
        bill=(Button)findViewById(R.id.billing);
        buymore=(Button)findViewById(R.id.buymore);
        qrScan=new IntentIntegrator(this);
        buymore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                qrScan.initiateScan();
            }
        });
        Bundle b=getIntent().getExtras();
        pid=b.getString("pid");
        pname=b.getString("pname");
        cost=b.getString("pamt");
        uname=b.getString("uname");
        pattustore = openOrCreateDatabase("pattubookdb",0, null);
        try {
            pattustore.execSQL("CREATE TABLE IF NOT EXISTS  billing ( keyid integer primary key autoincrement,pid text not null,pname text not null,amount integer,created_date date default CURRENT_DATE)");
            pattustore.execSQL("insert into billing values(NULL,'"+pid+"','"+pname+"','"+cost+"',datetime())");
        }   catch (java.lang.Exception paramLayoutInflater) {
            Log.d("errrorr", "insert   ");
        }


        Cursor repcursor=pattustore.rawQuery("select rowid _id,* from billing",null);
        ListView lvItems = (ListView) findViewById(R.id.listView);

        MyAdapter tempadapter=new MyAdapter(ProductList.this,repcursor);
        lvItems.setAdapter(tempadapter);
        lvItems.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Cursor cursor = (Cursor) parent.getItemAtPosition(position);
                name = cursor.getString(3);
                //Toast.makeText(getBaseContext(), name, Toast.LENGTH_SHORT).show();
                Intent i= new Intent(getBaseContext(),Product.class);
                i.putExtra("name",name);
                startActivity(i);


            }
        });


        bill.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent bill=new Intent(getBaseContext() ,Bill.class);
                bill.putExtra("uname",uname);
                startActivity(bill);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        productDataBaseAdapter=new ProductDataBaseAdapter(this);
        productDataBaseAdapter=productDataBaseAdapter.open();
        if (result != null) {
            //if qrcode has nothing in it
            if (result.getContents() == null) {
                Toast.makeText(this, "Result Not Found", Toast.LENGTH_LONG).show();
            } else {
                //if qr contains data
                try {
                    String content = result.getContents();
                    //Toast.makeText(this,result.getContents(),Toast.LENGTH_LONG).show();
                    String pname=productDataBaseAdapter.getProductname(content);
                    String storedid=productDataBaseAdapter.getProductid(pname);
                    //Toast.makeText(getApplicationContext(),"Real:"+content+" PN:"+pname+" ID:"+storedid,Toast.LENGTH_LONG).show();
                    if (storedid.equals(content)){
                        float cost=productDataBaseAdapter.getAmount(content);
                        Toast.makeText(getApplicationContext(),"Price: "+Float.toString(cost),Toast.LENGTH_LONG).show();
                        Intent pl=new Intent(getApplicationContext(),ProductList.class);
                        Bundle b=new Bundle();
                        b.putString("pid",storedid);
                        b.putString("pname",pname);
                        b.putString("pamt",Float.toString(cost));
                        pl.putExtras(b);
                        startActivity(pl);
                    }else{
                        Toast.makeText
                                (getApplicationContext(),"Product not found "+content,Toast.LENGTH_LONG).show();
                    }
                } catch (ArithmeticException e) {
                    e.printStackTrace();
                    //if control comes here
                    //that means the encoded format not matches
                    //in this case you can display whatever data is available on the qrcode
                    //to a toast
                    Toast.makeText(this,"wrong"+ result.getContents(), Toast.LENGTH_LONG).show();
                }
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }
    @Override
    public void onBackPressed() {
        if (back_pressed + 2000 > System.currentTimeMillis()){
            Intent i=new Intent(ProductList.this,Home.class);
            pattustore.execSQL("drop table billing");
            android.os.Process.killProcess(android.os.Process.myPid());
            ProductList.this.finish();
            startActivity(i);
        }
        else{
            Toast.makeText(getBaseContext(), "Press once again to quit Shopping", Toast.LENGTH_SHORT).show();
            back_pressed = System.currentTimeMillis();
        }
    }
}
