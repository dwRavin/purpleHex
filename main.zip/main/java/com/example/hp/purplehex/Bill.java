package com.example.hp.purplehex;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Bill extends Activity {
    LoginDataBaseAdapter loginDataBaseAdapter;
    SQLiteDatabase pattustore;
    Button f;
    TextView t;
    float amount,total,totalamount;
    String uname,amt;
    Cursor c;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bill);
        loginDataBaseAdapter=new LoginDataBaseAdapter(this);
        loginDataBaseAdapter=loginDataBaseAdapter.open();
            pattustore = openOrCreateDatabase("pattubookdb",0, null);
            t=(TextView)findViewById(R.id.textView6);
            f=(Button)findViewById(R.id.fnsh);
            uname= getIntent().getStringExtra("uname");

            totalamount =loginDataBaseAdapter.getAmount(uname);

            try {
                c = pattustore.rawQuery("select sum(amount) as Total from billing",null);

                c.moveToFirst();

                total = c.getFloat(c.getColumnIndex("Total"));// get final total
                t.setText("Total: "+total);

            }catch (java.lang.RuntimeException e){
                Log.d("error","eee");
            }

        amount=totalamount-total;
        amt=Float.toString(amount);
        loginDataBaseAdapter.updateBalance(uname,amt);
        f.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(Bill.this,Home.class);
                i.putExtra("name",uname);
                pattustore.execSQL("drop table billing");
                startActivity(i);
            }
        });

        }
}
