package com.example.hp.purplehex;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class LoginDataBaseAdapter
{
    static final String DATABASE_NAME = "easystore.db";
    static final int DATABASE_VERSION = 1;
    public static final int NAME_COLUMN = 1;
    // TODO: Create public field for each column in your table.
    static final String DATABASE_CREATE = "create table "+"LOGIN"+
            "( " +"KEYID"+" text primary key,"+ "USERNAME text ,PASSWORD text,AMOUNT float); ";

    public SQLiteDatabase db;
    private final Context context;
    private DataBaseHelper dbHelper;
    public LoginDataBaseAdapter(Context _context)
    {
        context = _context;
        dbHelper = new DataBaseHelper(context, DATABASE_NAME, null, DATABASE_VERSION);
    }



    public LoginDataBaseAdapter open() throws SQLException
    {
        db = dbHelper.getWritableDatabase();
        return this;
    }
    public void close()
    {
        db.close();
    }

/*    public SQLiteDatabase getDatabaseInstance()
    {
        return db;
    }
*/
    public void insertEntry(String key_id,String userName,String password,String amount)
    {
        ContentValues newValues = new ContentValues();
        newValues.put("KEYID",key_id);
        newValues.put("USERNAME", userName);
        newValues.put("PASSWORD",password);
        newValues.put("AMOUNT",amount);
        db.insert("LOGIN", null, newValues);
    }
    public int deleteEntry(String UserName)
    {
        String where="USERNAME=?";
        int numberOFEntriesDeleted= db.delete("LOGIN", where, new String[]{UserName}) ;
        return numberOFEntriesDeleted;
    }
    public String getUsername(String key_id)
    {
        Cursor cursor=db.query("LOGIN",null,  "KEYID=?", new String[]{key_id},null, null, null);
        if(cursor.getCount()<1)
        {
            cursor.close();
            return "NOT EXIST";
        }
        cursor.moveToFirst();
        String userName= cursor.getString(cursor.getColumnIndex("USERNAME"));
        cursor.close();
        return userName;

    }
    public String getKeyid(String userName)
    {
        Cursor cursor=db.query("LOGIN",null,  "USERNAME=?", new String[]{userName},null, null, null);
        if(cursor.getCount()<1)
        {
            cursor.close();
            return "0";
        }
        cursor.moveToFirst();
        String key_id= cursor.getString(cursor.getColumnIndex("KEYID"));
        cursor.close();
        return key_id;
    }
    public String getPassword(String userName)
    {
        Cursor cursor=db.query("LOGIN", null, " USERNAME=?", new String[]{userName}, null, null, null);

        if(cursor.getCount()<1)
        {
            cursor.close();
            return "NOT EXIST";
        }
        cursor.moveToFirst();
        String password= cursor.getString(cursor.getColumnIndex("PASSWORD"));
        cursor.close();
        return password;
    }
    public ContentValues qrdisplay(String userName, String amount){
        String where="USERNAME";
        ContentValues values = new ContentValues();
        values.put("AMOUNT",amount);
        return values;
    }
    public float getAmount(String userName) {
        db = dbHelper.getReadableDatabase();

       // Cursor cursor = db.query("LOGIN", new String[] { "ID", "USERNAME", "AMOUNT" }, "USERNAME" + "=?",
       //         new String[] { String.valueOf(username) }, null, null, null, null);
        Cursor cursor=db.query("LOGIN", null, " USERNAME=?", new String[]{userName}, null, null, null);
        if (cursor.getCount()<1)
        {
            cursor.close();
            return 0;
        }
        cursor.moveToFirst();
        float amount = cursor.getFloat(cursor.getColumnIndex("AMOUNT"));
        cursor.close();
        return amount;
    }


    public void updateBalance(String userName,String amt)
    {
        ContentValues updatedValues = new ContentValues();
        updatedValues.put("AMOUNT",amt);

        String where="USERNAME = ?";
        db.update("LOGIN",updatedValues, where, new String[]{userName});
    }
}