package com.example.hp.purplehex;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import org.json.JSONException;
import org.json.JSONObject;

public class landing_page extends Activity implements View.OnClickListener {
    private static long back_pressed;
    Button b1,b2;
    private IntentIntegrator qrScan;
    LoginDataBaseAdapter loginDataBaseAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_landing_page);
        b1=(Button)findViewById(R.id.log);
        b2=(Button)findViewById(R.id.sca);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(landing_page.this,MainActivity.class);
                startActivity(in);
            }
        });
        qrScan = new IntentIntegrator(this);
        b2.setOnClickListener(this);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        loginDataBaseAdapter=new LoginDataBaseAdapter(this);
        loginDataBaseAdapter=loginDataBaseAdapter.open();
        //String storedid = loginDataBaseAdapter.getKeyid(userName);
        if (result != null) {
            //if qrcode has nothing in it
            if (result.getContents() == null) {
                Toast.makeText(this, "Result Not Found", Toast.LENGTH_LONG).show();
            } else {
                //if qr contains data
                try {
                    String content = result.getContents();
                    String uname = loginDataBaseAdapter.getUsername(content);
                    //Toast.makeText(getApplicationContext(),content+"name:"+uname,Toast.LENGTH_LONG).show();
                    String storedid=loginDataBaseAdapter.getKeyid(uname);

                    if (storedid.equals(content)){
                        Intent in =new Intent(landing_page.this,Home.class);
                        Bundle b= new Bundle();
                        b.putString("name", uname);
                        in.putExtras(b);
                        startActivity(in);
                        landing_page.this.finish();
                    }else{
                        Toast.makeText(getApplicationContext(),"Customer not found "+content,Toast.LENGTH_LONG).show();
                    }
                } catch (ArithmeticException e) {
                    e.printStackTrace();
                    //if control comes here
                    //that means the encoded format not matches
                    //in this case you can display whatever data is available on the qrcode
                    //to a toast
                    Toast.makeText(this, result.getContents(), Toast.LENGTH_LONG).show();
                }
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public void onClick(View view)
    {
        qrScan.initiateScan();
    }

    @Override
    public void onBackPressed() {
        if (back_pressed + 2000 > System.currentTimeMillis()){
            android.os.Process.killProcess(android.os.Process.myPid());
            System.exit(0);
            landing_page.this.finish();
        }
        else{
            Toast.makeText(getBaseContext(), "Press once again to exit", Toast.LENGTH_SHORT).show();
            back_pressed = System.currentTimeMillis();
        }
    }

}
