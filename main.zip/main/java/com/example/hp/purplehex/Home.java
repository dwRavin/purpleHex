package com.example.hp.purplehex;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import org.w3c.dom.Text;

public class Home extends Activity{
    private static long back_pressed;
    LoginDataBaseAdapter loginDataBaseAdapter;
    TextView name,id;
    String uname;
    ProductDataBaseAdapter productDataBaseAdapter;
    private IntentIntegrator qrScan;
    @Override
        protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        name = (TextView)findViewById(R.id.name);
        id = (TextView)findViewById(R.id.id);
        Button buy = (Button)findViewById(R.id.buy);
        qrScan=new IntentIntegrator(this);
        loginDataBaseAdapter=new LoginDataBaseAdapter(this);
        loginDataBaseAdapter=loginDataBaseAdapter.open();
        Bundle b =getIntent().getExtras();
        name.setText(b.getCharSequence("name"));
        id.setText(b.getCharSequence("id"));
        uname=name.getText().toString();
        float totalamount =loginDataBaseAdapter.getAmount(uname);
        String amt=Float.toString(totalamount);
        //Toast.makeText(getBaseContext(),"hello:  "+amt,Toast.LENGTH_LONG).show();
        buy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {qrScan.initiateScan();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        productDataBaseAdapter=new ProductDataBaseAdapter(this);
        productDataBaseAdapter=productDataBaseAdapter.open();
        if (result != null) {
            //if qrcode has nothing in it
            if (result.getContents() == null) {
                Toast.makeText(this, "Result Not Found", Toast.LENGTH_LONG).show();
            } else {
                //if qr contains data
                try {
                    String content = result.getContents();
                    //Toast.makeText(this,result.getContents(),Toast.LENGTH_LONG).show();
                    String pname=productDataBaseAdapter.getProductname(content);
                    String storedid=productDataBaseAdapter.getProductid(pname);
                    //Toast.makeText(getApplicationContext(),"Real:"+content+" PN:"+pname+" ID:"+storedid,Toast.LENGTH_LONG).show();
                    if (storedid.equals(content)){
                        float cost=productDataBaseAdapter.getAmount(content);
                        Toast.makeText(getApplicationContext(),"Price: "+Float.toString(cost),Toast.LENGTH_LONG).show();
                        Intent pl=new Intent(getApplicationContext(),ProductList.class);
                        Bundle b=new Bundle();
                        b.putString("pid",storedid);
                        b.putString("pname",pname);
                        b.putString("pamt",Float.toString(cost));
                        b.putString("uname",uname);
                        pl.putExtras(b);
                        startActivity(pl);
                    }else{
                        Toast.makeText
                                (getApplicationContext(),"Product not found "+content,Toast.LENGTH_LONG).show();
                    }
                } catch (ArithmeticException e) {
                    e.printStackTrace();
                    //if control comes here
                    //that means the encoded format not matches
                    //in this case you can display whatever data is available on the qrcode
                    //to a toast
                    Toast.makeText(this,"wrong"+ result.getContents(), Toast.LENGTH_LONG).show();
                }
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public void onBackPressed() {
        if (back_pressed + 2000 > System.currentTimeMillis()){
            startActivity(new Intent(Home.this,landing_page.class));
            Home.this.finish();
        }
        else{
            Toast.makeText(getBaseContext(), "Press once again to logout", Toast.LENGTH_SHORT).show();
            back_pressed = System.currentTimeMillis();
        }
    }
}
