package com.example.hp.purplehex;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ProductAdd extends Activity {
    EditText pid,pname,amt;
    Button padd;
    ProductDataBaseAdapter productDataBaseAdapter;
    private static long back_pressed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_add);
        pid=(EditText)findViewById(R.id.product_id);
        pname=(EditText)findViewById(R.id.ProductName);
        amt=(EditText)findViewById(R.id.amount);
        productDataBaseAdapter=new ProductDataBaseAdapter(this);
        productDataBaseAdapter=productDataBaseAdapter.open();
        padd=(Button)findViewById(R.id.add_product);
        padd.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
// TODO Auto-generated method stub

                String PName=pname.getText().toString();
                String amount=amt.getText().toString();
                String p_id=pid.getText().toString();
                if(PName.equals("")||amount.equals("")||p_id.equals(""))
                {
                    Toast.makeText(getApplicationContext(), "Field Vaccant", Toast.LENGTH_LONG).show();
                }

                else
                {
                    productDataBaseAdapter.insertEntry(p_id,PName, amount);
                    Toast.makeText(getApplicationContext(), "Product Added Successfully", Toast.LENGTH_LONG).show();
                    Intent i=new Intent(ProductAdd.this,Admin_Home.class);
                    startActivity(i);
                    ProductAdd.this.finish();
                }
            }
        });
    }
    @Override
    protected void onDestroy() {
// TODO Auto-generated method stub
        super.onDestroy();
        productDataBaseAdapter.close();
    }

    @Override
    public void onBackPressed() {
        if (back_pressed + 2000 > System.currentTimeMillis()){
            ProductAdd.this.finish();
        }
        else{
            Toast.makeText(getBaseContext(), "Press once again to exit", Toast.LENGTH_SHORT).show();
            back_pressed = System.currentTimeMillis();
        }
    }
}