package com.example.hp.purplehex;

import android.app.Activity;
import android.content.Intent;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {
//    Button B;
    LoginDataBaseAdapter loginDataBaseAdapter;
    //String uname,pwd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        loginDataBaseAdapter=new LoginDataBaseAdapter(this);
        loginDataBaseAdapter=loginDataBaseAdapter.open();
        final EditText editTextUserName=(EditText)findViewById(R.id.user);
        final EditText editTextPassword=(EditText)findViewById(R.id.pass);
        Button btnSignIn=(Button)findViewById(R.id.login);
        btnSignIn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String userName=editTextUserName.getText().toString();
                String password=editTextPassword.getText().toString();
                String storedPassword=loginDataBaseAdapter.getPassword(userName);
                if(password.equals("pass") && userName.equals("admin")){
                    Intent inten = new Intent(MainActivity.this,Admin_Home.class);
                    startActivity(inten);
                    MainActivity.this.finish();
                }
                else if(password.equals(storedPassword))
                {
                    Intent in =new Intent(MainActivity.this,Home.class);
                    Bundle b= new Bundle();
                    b.putString("name", userName);
                    in.putExtras(b);
                    startActivity(in);
                    MainActivity.this.finish();
                }
                else
                {
                    Toast.makeText(MainActivity.this, "User Name or Password does not match", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}