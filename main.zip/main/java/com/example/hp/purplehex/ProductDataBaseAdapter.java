package com.example.hp.purplehex;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class ProductDataBaseAdapter {
        static final String DATABASE_NAME = "easystore.db";
        static final int DATABASE_VERSION = 1;
        public static final int NAME_COLUMN = 1;
        // TODO: Create public field for each column in your table.
        static final String DATABASE_CREATE = "create table "+"PRODUCT"+
                "( " +"PRODUCTID"+" text primary key,"+ "PNAME text ,AMOUNT float); ";

        public SQLiteDatabase db;
        private final Context context;
        private DataBaseHelper dbHelper;
        public ProductDataBaseAdapter(Context _context)
        {
            context = _context;
            dbHelper = new DataBaseHelper(context, DATABASE_NAME, null, DATABASE_VERSION);
        }



        public ProductDataBaseAdapter open() throws SQLException
        {
            db = dbHelper.getWritableDatabase();
            return this;
        }
        public void close()
        {
            db.close();
        }

        public SQLiteDatabase getDatabaseInstance()
        {
                return db;
        }

        public void insertEntry(String key_id,String productName,String amount)
        {
            ContentValues newValues = new ContentValues();
            newValues.put("PRODUCTID",key_id);
            newValues.put("PNAME", productName);
            newValues.put("AMOUNT",amount);
            db.insert("PRODUCT", null, newValues);
        }
        public int deleteEntry(String UserName)
        {
            String where="PNAME=?";
            int numberOFEntriesDeleted= db.delete("PRODUCT", where, new String[]{UserName}) ;
            return numberOFEntriesDeleted;
        }
        public String getProductname(String key_id)
        {
            Cursor cursor=db.query("PRODUCT",null,  "PRODUCTID=?", new String[]{key_id},null, null, null);
            if(cursor.getCount()<1)
            {
                cursor.close();
                return "NOT EXIST";
            }
            cursor.moveToFirst();
            String productName= cursor.getString(cursor.getColumnIndex("PNAME"));
            cursor.close();
            return productName;

        }
        public String getProductid(String name)
        {
            Cursor cursor=db.query("PRODUCT",null,  "PNAME=?", new String[]{name},null, null, null);
            if(cursor.getCount()<1)
            {
                cursor.close();
                return "0";
            }
            cursor.moveToFirst();
            String pid= cursor.getString(cursor.getColumnIndex("PRODUCTID"));
            cursor.close();
            return pid;
        }
        public ContentValues qrdisplay(String userName, String amount){
            String where="USERNAME";
            ContentValues values = new ContentValues();
            values.put("AMOUNT",amount);
            return values;
        }
        public float getAmount(String productid) {
            db = dbHelper.getReadableDatabase();

            // Cursor cursor = db.query("LOGIN", new String[] { "ID", "USERNAME", "AMOUNT" }, "USERNAME" + "=?",
            //         new String[] { String.valueOf(username) }, null, null, null, null);
            Cursor cursor=db.query("PRODUCT", null, " PRODUCTID=?", new String[]{productid}, null, null, null);
            if (cursor.getCount()<1)
            {
                cursor.close();
                return 0;
            }
            cursor.moveToFirst();
            float amount = cursor.getFloat(cursor.getColumnIndex("AMOUNT"));
            cursor.close();
            return amount;
        }


        public void updateEntry(String userName,String password)
        {
            ContentValues updatedValues = new ContentValues();
            updatedValues.put("USERNAME", userName);
            updatedValues.put("PASSWORD",password);

            String where="USERNAME = ?";
            db.update("PRODUCT",updatedValues, where, new String[]{userName});
        }
    }

